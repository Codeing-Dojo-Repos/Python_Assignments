import Pet as animals
import ninja as warrior

domo = animals.Pet('domo-kun', 'dog', 'play dead')
Sensei1 = warrior.Ninja('domo', 'kun', 'goldfish', 'chicken', domo)

Sensei1.feed()
Sensei1.walk()
Sensei1.bathe()