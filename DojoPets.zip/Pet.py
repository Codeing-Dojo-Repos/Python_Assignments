
class Pet:
    def __init__(self, name , type , tricks ):
        self.name = name
        self.type = type
        self.tricks = tricks

        self.health = 10
        self.energy = 10

    def sleep(self):
        print(f'{self.name} is sleeping')
        self.energy += 25

    def eat(self): # - increases the pet's energy by 5 & health by 10
        print(f'{self.name} is eating')
        self.energy += 25
        self.health += 10

    def play(self): # increases the pet's health by 5
        print(f'{self.name} is playing')
        self.health += 5

    def noise(self): # - prints out the pet's sound
        print('ruff ruff!')