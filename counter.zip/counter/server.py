from flask import Flask, render_template, request, redirect, session
app = Flask(__name__)
app.secret_key = "apple sauce"


@app.route('/')
def render_count():
    if 'count'  in session:
        print('key exists')
        session['count'] += 1
    else:
        print("No exists")
        session['count'] = 0
         
    print(f'Count is {session["count"]}')
    return render_template('index.html')


@app.route('/increment2')
def inc_two():
    if 'count' in session:
        print('key exists')
        session['count'] += 1
    else:
        print("No exists")
        session['count'] = 1
    return redirect('/') # will add 1

@app.route('/reset')
def reset_counter():
    #session['count'] = 0
    session.clear()
    return redirect('/')

@app.route('/destroy_session')
def destroy_session():
    session.clear()
    return redirect('/')


if __name__=="__main__":  
   app.run(debug=True)  