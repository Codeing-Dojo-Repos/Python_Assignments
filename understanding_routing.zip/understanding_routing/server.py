from flask import Flask
app = Flask(__name__) 

@app.route('/')
def hello_world():
    return 'Hello World'

@app.route('/dojo')
def return_dojo():
    return 'Dojo!'

@app.route('/greet/<string:name>')
def greet(name):
    return f'Hello {name}'

@app.route('/repeat/<string:word>/<int:count>')
def repeat(word, count):
    s = word
    for i in range(count-1):
        s += f' {word}'
    return s

@app.errorhandler(404)
def handle_404(e):
    return "Sorry! No response. Try again."

if __name__=="__main__":
    app.run(debug=True) 